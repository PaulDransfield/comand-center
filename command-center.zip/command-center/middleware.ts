// middleware.ts
//
// Runs on EVERY request before it reaches the page or API route.
// Two jobs:
//   1. Refresh the user's Supabase session (keeps them logged in)
//   2. Redirect unauthenticated users to /login
//
// Think of this as a security guard at the door of every room in the app.

import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

// These routes don't need a login — everyone can access them
const PUBLIC_PATHS = [
  '/login',
  '/signup',
  '/forgot-password',
  '/reset-password',
  '/privacy',
  '/terms',
  '/api/auth',        // login/signup/callback API routes
  '/api/webhooks',    // Stripe webhooks (authenticated by Stripe signature, not session)
  '/api/cron',        // Vercel cron (authenticated by CRON_SECRET header)
  '/api/health',      // health check (public)
]

export async function middleware(request: NextRequest) {
  // Start with a plain "continue" response
  let supabaseResponse = NextResponse.next({ request })

  const { pathname } = request.nextUrl

  // Skip auth check for public routes
  const isPublic = PUBLIC_PATHS.some(path => pathname.startsWith(path))
  if (isPublic) return supabaseResponse

  // Create a Supabase client that can read/write cookies from this request
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll()
        },
        setAll(cookiesToSet) {
          // Write updated cookies to both the request and the response
          // This is what keeps the session alive across page loads
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value)
          )
          supabaseResponse = NextResponse.next({ request })
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          )
        },
      },
    }
  )

  // Get the current user (also refreshes the session token if needed)
  const { data: { user } } = await supabase.auth.getUser()

  // If no user and not a public route → send to login
  if (!user) {
    const loginUrl = request.nextUrl.clone()
    loginUrl.pathname = '/login'
    // Remember where they were trying to go, so we can redirect back after login
    loginUrl.searchParams.set('redirectTo', pathname)
    return NextResponse.redirect(loginUrl)
  }

  return supabaseResponse
}

// Tell Next.js which routes to run this middleware on.
// The pattern excludes static files, images, and Next.js internals.
export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico|css|js)$).*)',
  ],
}
