// app/dashboard/layout.tsx
//
// The DASHBOARD LAYOUT — wraps every page inside /dashboard.
// Provides:
//   - The BizContext (multi-business state) to all child pages
//   - The top navigation bar
//   - The vertical icon sidebar
//   - The support widget (floating button)
//
// Any page under /dashboard/ automatically gets the nav + sidebar.

import type { Metadata } from 'next'
import { BizProvider }   from '@/context/BizContext'
import Topbar            from '@/components/dashboard/Topbar'
import Sidebar           from '@/components/dashboard/Sidebar'

export const metadata: Metadata = {
  title: 'Dashboard',
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    // BizProvider loads businesses from /api/businesses on mount
    // Every child component can call useBiz() to access state
    <BizProvider>
      <div style={styles.shell}>

        {/* Top bar: logo, business switcher, search, user menu */}
        <Topbar />

        <div style={styles.body}>
          {/* Left icon sidebar: links to main sections */}
          <Sidebar />

          {/* The actual page content (dashboard, notebook, tracker, etc.) */}
          <main style={styles.main}>
            {children}
          </main>
        </div>

      </div>
    </BizProvider>
  )
}

const styles: Record<string, React.CSSProperties> = {
  shell: {
    display:       'grid',
    gridTemplateRows: 'var(--nav-h) 1fr',
    height:        '100vh',
    overflow:      'hidden',
    background:    'var(--parchment)',
  },
  body: {
    display:   'grid',
    gridTemplateColumns: '64px 1fr',
    overflow:  'hidden',
  },
  main: {
    overflowY: 'auto',
    height:    '100%',
  },
}
