// lib/supabase/server.ts
//
// The SERVER-SIDE Supabase clients.
// Use these in API routes, Server Components, and middleware.
// They never run in the browser.
//
// TWO clients:
//   createClient()      — uses the anon key, respects RLS (safe for user requests)
//   createAdminClient() — uses service_role key, BYPASSES RLS (admin operations only)
//
// Rule of thumb:
//   Reading user's own data  → createClient()
//   Writing on behalf of user after verifying their org → createAdminClient()
//   Stripe webhooks, cron jobs, admin operations → createAdminClient()

import { createServerClient } from '@supabase/ssr'
import { cookies }            from 'next/headers'

// Standard server client — respects RLS, tied to the logged-in user
export function createClient() {
  const cookieStore = cookies()

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        // Read cookies from the incoming request
        getAll() {
          return cookieStore.getAll()
        },
        // Write cookies to the outgoing response (for session refresh)
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            )
          } catch {
            // setAll called from a Server Component where cookies can't be set.
            // This is fine — the middleware handles session refresh.
          }
        },
      },
    }
  )
}

// Admin client — bypasses ALL Row Level Security.
// ⚠️  Only use this when you've already verified the user's org_id in application code.
// ⚠️  Never expose this client or SUPABASE_SERVICE_ROLE_KEY to the browser.
export function createAdminClient() {
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    {
      // Admin client doesn't need cookies — it authenticates via the service role key
      cookies: {
        getAll() { return [] },
        setAll() {},
      },
    }
  )
}
