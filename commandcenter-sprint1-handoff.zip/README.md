# CommandCenter Sprint 1 Handoff Package
> Generated 2026-04-26

## What's in this package

- **`CLAUDE-CODE-HANDOFF.md`** — the operational prompt to give Claude Code. Self-contained, references REVIEW.md for context, gives 5 tasks with file:line citations and acceptance criteria.
- **`REVIEW.md`** — full architectural review (the document you generated this from). Used as background reference by Claude Code.

## How to use

### Step 1 — drop both files at the repo root
```powershell
cp CLAUDE-CODE-HANDOFF.md C:\Users\pauld\Desktop\comand-center\
cp REVIEW.md              C:\Users\pauld\Desktop\comand-center\
```

Add them to `.gitignore` if you don't want them committed (they're work documents, not deliverables):
```
# Sprint handoff docs (local reference only)
CLAUDE-CODE-HANDOFF.md
REVIEW.md
```

### Step 2 — apply M028–M031 first (Task 0 in the handoff)

The first thing Claude Code is instructed to do is ask you whether M028, M029, M030, M031 have been applied. If you haven't run them yet:

1. Open https://app.supabase.com/project/llzmixkrysduztsvmfzi/sql
2. Open `M028-FORTNOX-PROPER-FIX.sql`, paste, run.
3. Repeat for M029, M030, M031 in order.
4. Verify with the verification queries at the bottom of each file.

Reply "yes" when Claude Code asks.

### Step 3 — start Claude Code with the prompt

In your terminal at the repo root:
```bash
claude
```

Then paste:
```
Read CLAUDE-CODE-HANDOFF.md and follow it. Begin with Task 0.
```

That's it. Claude Code will:
- Read CLAUDE.md and the handoff doc
- Ask you about M028–M031
- Work through Tasks 1–5 in order
- Update FIXES.md after each task
- Commit per task (your auto-push hook handles the rest)
- Stop at Task 5 and produce an end-of-sprint summary

### Step 4 — between tasks

Claude Code will likely pause for confirmation between major tasks (especially around Task 3, where there's a join-table migration). That's expected. Review its plan, give it a green light or push back.

If you want to do this in one sitting, set aside ~5 hours. Tasks 1–2 are fast (~75 min). Task 3 is the chunky one (~2 hr). Tasks 4–5 together ~2 hr.

If you want to split: Tasks 1–2 are a clean half-day; Task 3 is a clean half-day; Tasks 4–5 are a clean half-day.

## What's NOT in this sprint

The review identified more issues than what's in the handoff. Sprint 1 is the critical/high-impact subset. Deferred to Sprint 2:
- Consolidate the two auth helpers (Task 6)
- Stripe webhook `'solo'` plan default fix
- Standardise CRON_SECRET checks
- Wrap aggregator in `waitUntil`
- Move root cruft to `archive/`
- Vitest setup + tests for `lib/finance/` and `lib/fortnox/`
- Drop `@ts-nocheck` from load-bearing files
- Move to Supabase CLI migrations

The handoff explicitly tells Claude Code not to touch these. If Claude Code drifts, redirect it.

## Sanity checks before you start

- Auto-push hook is working (`git status` should be clean before you start).
- You're on `main` (or whatever your prod branch is).
- You've got 30 min of buffer to apply M028–M031 and verify.
- Vercel deploy is not paused (the auto-push will trigger a deploy mid-sprint; that's fine, but confirm rollback is one click away).

## If something goes sideways

- **Build breaks:** `git revert HEAD` then ask Claude Code to retry the task with the failure message.
- **A migration won't apply:** the verification query at the bottom of each migration file tells you whether the change took. If a constraint already exists with a different name, the migration is idempotent — re-run safely.
- **Multi-org `.maybeSingle()` change breaks Paul's own login:** unlikely (you're a single-org user) but if it does, `git revert` and tell Claude Code "the order-by-created_at picked a different membership than expected; investigate".
- **`fortnox_supersede_links` migration runs but Reject path doesn't restore predecessors:** Task 3 is the most likely place for a regression. Test by re-uploading a corrected multi-month PDF, then rejecting it, and confirming all prior single-month uploads for that range come back to `'applied'`.

Good luck.
