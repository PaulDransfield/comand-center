// app/(auth)/login/page.tsx
//
// The login page. Supports:
//   - Email + password login
//   - Sign up for a new account
//   - "Forgot password" (sends reset email)
//
// The (auth) folder name in brackets means it's a Route Group —
// it doesn't affect the URL, just groups auth pages together.
// URL is still: /login

'use client'  // This page runs in the browser (has forms, user interaction)

import { useState }    from 'react'
import { useRouter }   from 'next/navigation'
import { createClient } from '@/lib/supabase/client'

// Which form is showing
type Mode = 'login' | 'signup' | 'forgot'

export default function LoginPage() {
  const router   = useRouter()
  const supabase = createClient()

  const [mode,    setMode]    = useState<Mode>('login')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')        // success messages (green)
  const [error,   setError]   = useState('')        // error messages (red)

  // Form field values
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [orgName,  setOrgName]  = useState('')

  // ── LOGIN ─────────────────────────────────────────────────────
  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    const { error } = await supabase.auth.signInWithPassword({ email, password })

    if (error) {
      // Make Supabase's technical error messages friendlier
      if (error.message.includes('Invalid login')) {
        setError('Incorrect email or password. Please try again.')
      } else if (error.message.includes('Email not confirmed')) {
        setError('Please verify your email first. Check your inbox for the verification link.')
      } else {
        setError(error.message)
      }
      setLoading(false)
      return
    }

    // Logged in — go to the dashboard
    router.push('/dashboard')
    router.refresh()
  }

  // ── SIGN UP ───────────────────────────────────────────────────
  async function handleSignup(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    const res  = await fetch('/api/auth/signup', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ email, password, fullName, orgName }),
    })

    const data = await res.json()

    if (!res.ok) {
      setError(data.error || 'Signup failed. Please try again.')
      setLoading(false)
      return
    }

    setMessage('Account created! Check your email for a verification link.')
    setLoading(false)
  }

  // ── FORGOT PASSWORD ───────────────────────────────────────────
  async function handleForgot(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/api/auth/callback?next=/reset-password`,
    })

    if (error) {
      setError(error.message)
    } else {
      setMessage('Reset link sent! Check your email.')
    }

    setLoading(false)
  }

  // ── RENDER ────────────────────────────────────────────────────
  return (
    <div style={styles.page}>
      <div style={styles.card}>

        {/* Logo / brand */}
        <div style={styles.brand}>
          <div style={styles.brandLogo}>CC</div>
          <span style={styles.brandName}>CommandCenter</span>
        </div>

        {/* Title */}
        <h1 style={styles.title}>
          {mode === 'login'  && 'Welcome back'}
          {mode === 'signup' && 'Create your account'}
          {mode === 'forgot' && 'Reset your password'}
        </h1>

        <p style={styles.subtitle}>
          {mode === 'login'  && 'Sign in to your restaurant command center'}
          {mode === 'signup' && '30-day free trial · No credit card required'}
          {mode === 'forgot' && "We'll send a reset link to your email"}
        </p>

        {/* Success message */}
        {message && (
          <div style={styles.messageBox}>
            ✓ {message}
          </div>
        )}

        {/* Error message */}
        {error && (
          <div style={styles.errorBox}>
            {error}
          </div>
        )}

        {/* FORM */}
        <form onSubmit={mode === 'login' ? handleLogin : mode === 'signup' ? handleSignup : handleForgot}>

          {/* Full name — only on signup */}
          {mode === 'signup' && (
            <div style={styles.field}>
              <label style={styles.label}>Your name</label>
              <input
                className="input"
                type="text"
                placeholder="Paul Dransfield"
                value={fullName}
                onChange={e => setFullName(e.target.value)}
                required
              />
            </div>
          )}

          {/* Organisation name — only on signup */}
          {mode === 'signup' && (
            <div style={styles.field}>
              <label style={styles.label}>Restaurant / company name</label>
              <input
                className="input"
                type="text"
                placeholder="Vero Italiano AB"
                value={orgName}
                onChange={e => setOrgName(e.target.value)}
                required
              />
            </div>
          )}

          {/* Email — always shown */}
          <div style={styles.field}>
            <label style={styles.label}>Email address</label>
            <input
              className="input"
              type="email"
              placeholder="paul@veroitaliano.se"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              autoComplete="email"
            />
          </div>

          {/* Password — not on forgot */}
          {mode !== 'forgot' && (
            <div style={styles.field}>
              <label style={styles.label}>Password</label>
              <input
                className="input"
                type="password"
                placeholder={mode === 'signup' ? 'At least 8 characters' : '••••••••'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
                minLength={mode === 'signup' ? 8 : 1}
                autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
              />
            </div>
          )}

          {/* Forgot password link */}
          {mode === 'login' && (
            <div style={{ textAlign: 'right', marginBottom: 16 }}>
              <button
                type="button"
                style={styles.link}
                onClick={() => { setMode('forgot'); setError(''); setMessage('') }}
              >
                Forgot password?
              </button>
            </div>
          )}

          {/* Submit button */}
          <button
            type="submit"
            className="btn btn-primary btn-full"
            disabled={loading}
            style={{ marginTop: 4 }}
          >
            {loading
              ? <><span className="spin">⟳</span> Please wait…</>
              : mode === 'login'  ? 'Sign in'
              : mode === 'signup' ? 'Create account'
              : 'Send reset link'}
          </button>
        </form>

        {/* Switch between login and signup */}
        <div style={styles.switchRow}>
          {mode === 'login' ? (
            <>
              Don't have an account?{' '}
              <button style={styles.link} onClick={() => { setMode('signup'); setError(''); setMessage('') }}>
                Sign up free
              </button>
            </>
          ) : mode === 'signup' ? (
            <>
              Already have an account?{' '}
              <button style={styles.link} onClick={() => { setMode('login'); setError(''); setMessage('') }}>
                Sign in
              </button>
            </>
          ) : (
            <button style={styles.link} onClick={() => { setMode('login'); setError(''); setMessage('') }}>
              ← Back to login
            </button>
          )}
        </div>

      </div>
    </div>
  )
}

// ── Inline styles ─────────────────────────────────────────────────
// (matches the design from login-page.html)
const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: '100vh',
    background: 'var(--parchment)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '20px',
  },
  card: {
    background: 'var(--white)',
    border: '1px solid var(--border)',
    borderRadius: '16px',
    padding: '36px',
    width: '400px',
    maxWidth: '100%',
    boxShadow: '0 4px 24px rgba(0,0,0,.08)',
  },
  brand: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    marginBottom: '24px',
  },
  brandLogo: {
    width: '32px',
    height: '32px',
    borderRadius: '8px',
    background: 'var(--navy)',
    color: 'white',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontFamily: 'var(--display)',
    fontSize: '13px',
    fontWeight: '700',
  },
  brandName: {
    fontFamily: 'var(--display)',
    fontSize: '16px',
    fontWeight: '600',
    color: 'var(--navy)',
  },
  title: {
    fontFamily: 'var(--display)',
    fontSize: '24px',
    fontWeight: '300',
    fontStyle: 'italic',
    color: 'var(--navy)',
    marginBottom: '6px',
  },
  subtitle: {
    fontSize: '13px',
    color: 'var(--ink-3)',
    marginBottom: '24px',
    lineHeight: '1.5',
  },
  messageBox: {
    background: 'var(--green-lt)',
    border: '1px solid var(--green-mid)',
    borderRadius: '8px',
    padding: '10px 14px',
    fontSize: '13px',
    color: 'var(--green)',
    marginBottom: '16px',
  },
  errorBox: {
    background: 'var(--red-lt)',
    border: '1px solid var(--red-mid)',
    borderRadius: '8px',
    padding: '10px 14px',
    fontSize: '13px',
    color: 'var(--red)',
    marginBottom: '16px',
  },
  field: {
    marginBottom: '14px',
  },
  label: {
    display: 'block',
    fontSize: '11px',
    fontWeight: '700',
    textTransform: 'uppercase' as const,
    letterSpacing: '.08em',
    color: 'var(--ink-4)',
    marginBottom: '5px',
  },
  link: {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    color: 'var(--blue)',
    fontSize: '13px',
    fontFamily: 'var(--font)',
    padding: '0',
    textDecoration: 'underline',
  },
  switchRow: {
    textAlign: 'center' as const,
    marginTop: '20px',
    fontSize: '13px',
    color: 'var(--ink-3)',
  },
}
