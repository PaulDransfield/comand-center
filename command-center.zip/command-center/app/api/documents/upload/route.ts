// app/api/documents/upload/route.ts
//
// DOCUMENT UPLOAD — saves files to Supabase Storage and kicks off text extraction.
//
// Flow:
//   1. Client sends multipart/form-data with the file + notebookId
//   2. We validate: file type, size, plan limits
//   3. Upload to Supabase Storage at: documents/{orgId}/{notebookId}/{filename}
//   4. Insert a row in notebook_documents with metadata
//   5. Extract text (basic extraction happens here; deep extraction is async)
//   6. Return the document record
//
// POST /api/documents/upload
// Content-Type: multipart/form-data
// Body: file, notebookId

import { NextRequest, NextResponse }  from 'next/server'
import { createAdminClient }          from '@/lib/supabase/server'
import { getOrgFromRequest }          from '@/lib/auth/get-org'
import { rateLimit }                  from '@/lib/middleware/rate-limit'
import { getLimits }                  from '@/lib/stripe/config'

// Allowed file types and their MIME types
const ALLOWED_TYPES: Record<string, string> = {
  'application/pdf':            'pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':       'xlsx',
  'text/csv':                   'csv',
  'text/plain':                 'txt',
  'image/jpeg':                 'jpg',
  'image/png':                  'png',
  'image/webp':                 'webp',
}

const MAX_FILE_SIZE_BYTES = 50 * 1024 * 1024  // 50MB hard limit (Supabase Storage default)

export async function POST(req: NextRequest) {
  // ── 1. Auth + rate limit ──────────────────────────────────────
  const auth = await getOrgFromRequest(req)
  if (!auth) return NextResponse.json({ error: 'Not authenticated' }, { status: 401 })

  const limit = await rateLimit(req, auth, 'upload')
  if (!limit.ok) return limit.response!

  // ── 2. Parse multipart form ───────────────────────────────────
  let formData: FormData
  try {
    formData = await req.formData()
  } catch {
    return NextResponse.json({ error: 'Invalid form data' }, { status: 400 })
  }

  const file       = formData.get('file')       as File   | null
  const notebookId = formData.get('notebookId') as string | null

  if (!file)       return NextResponse.json({ error: 'No file provided'       }, { status: 400 })
  if (!notebookId) return NextResponse.json({ error: 'No notebookId provided' }, { status: 400 })

  // ── 3. Validate file type ─────────────────────────────────────
  const ext = ALLOWED_TYPES[file.type]
  if (!ext) {
    return NextResponse.json({
      error: `File type "${file.type}" not supported. Allowed: PDF, DOCX, XLSX, CSV, TXT, images.`,
    }, { status: 400 })
  }

  // ── 4. Validate file size ─────────────────────────────────────
  if (file.size > MAX_FILE_SIZE_BYTES) {
    return NextResponse.json({
      error: `File too large (${Math.round(file.size / 1024 / 1024)}MB). Maximum is 50MB.`,
    }, { status: 400 })
  }

  const supabase = createAdminClient()

  // ── 5. Check plan document limit ─────────────────────────────
  const limits = getLimits(auth.plan)
  const { count: docCount } = await supabase
    .from('notebook_documents')
    .select('id', { count: 'exact', head: true })
    .eq('org_id', auth.orgId)

  if ((docCount ?? 0) >= limits.documents) {
    return NextResponse.json({
      error:       `Document limit reached (${limits.documents} on your ${auth.plan} plan).`,
      code:        'USAGE_LIMIT',
      upgrade_url: '/upgrade',
    }, { status: 402 })
  }

  // ── 6. Verify notebook belongs to this org ───────────────────
  const { data: notebook } = await supabase
    .from('notebooks')
    .select('id')
    .eq('id', notebookId)
    .eq('org_id', auth.orgId)
    .single()

  if (!notebook) {
    return NextResponse.json({ error: 'Notebook not found' }, { status: 404 })
  }

  // ── 7. Upload to Supabase Storage ────────────────────────────
  // Path: documents/{orgId}/{notebookId}/{timestamp}-{filename}
  // The orgId prefix is what the RLS policy uses to isolate tenants.
  const sanitisedName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_')
  const storagePath   = `${auth.orgId}/${notebookId}/${Date.now()}-${sanitisedName}`

  const arrayBuffer = await file.arrayBuffer()
  const fileBuffer  = new Uint8Array(arrayBuffer)

  const { data: uploadData, error: uploadError } = await supabase.storage
    .from('documents')
    .upload(storagePath, fileBuffer, {
      contentType: file.type,
      upsert:      false,  // never overwrite — each upload gets a unique timestamp prefix
    })

  if (uploadError) {
    console.error('Storage upload failed:', uploadError)
    return NextResponse.json({ error: 'Failed to upload file. Please try again.' }, { status: 500 })
  }

  // ── 8. Guess document type from filename ──────────────────────
  const docType = guessDocType(file.name)

  // ── 9. Basic text extraction (plain text only) ────────────────
  // Full extraction (PDF parsing, XLSX, etc.) should run as a background job.
  // For now, we just record the file — the user can ask AI questions about it
  // once the background processor picks it up.
  let extractedText: string | null = null

  if (file.type === 'text/plain' || file.type === 'text/csv') {
    // Safe to extract in-request for small plain text files
    try {
      extractedText = new TextDecoder().decode(fileBuffer).slice(0, 100_000)
    } catch { /* ignore */ }
  }

  // ── 10. Save document record ──────────────────────────────────
  const { data: doc, error: dbError } = await supabase
    .from('notebook_documents')
    .insert({
      org_id:         auth.orgId,
      notebook_id:    notebookId,
      name:           file.name,
      file_type:      ext,
      file_size:      file.size,
      storage_path:   storagePath,
      extracted_text: extractedText,
      chunk_count:    0,
      doc_type:       docType,
      is_pinned:      true,   // pin by default — user can unpin
    })
    .select()
    .single()

  if (dbError) {
    // Clean up the uploaded file if DB insert failed
    await supabase.storage.from('documents').remove([storagePath])
    console.error('Document record failed:', dbError)
    return NextResponse.json({ error: 'Failed to save document record.' }, { status: 500 })
  }

  return NextResponse.json({
    id:          doc.id,
    name:        doc.name,
    ext,
    size:        doc.file_size,
    chunks:      0,
    pinned:      true,
    doc_type:    docType,
    summary:     null,
    processing:  extractedText === null,  // true = needs background processing
  })
}

function guessDocType(filename: string): string {
  const n = filename.toLowerCase()
  if (/resultat|p.l|income|profit|loss/.test(n))  return 'p_and_l'
  if (/faktura|invoice|fakt/.test(n))              return 'invoice'
  if (/bank|kontoutdrag|statement/.test(n))        return 'bank_statement'
  if (/budget|prognos|forecast/.test(n))           return 'budget'
  if (/avtal|kontrakt|contract|agreement/.test(n)) return 'contract'
  return 'other'
}
