// lib/auth/get-org.ts
//
// Helper used at the top of every API route.
// Extracts who is making the request and which organisation they belong to.
//
// Usage in an API route:
//   const auth = await getOrgFromRequest(request)
//   if (!auth) return Response.json({ error: 'Not authenticated' }, { status: 401 })
//   // now use auth.orgId, auth.userId, auth.role, auth.plan

import { createAdminClient } from '@/lib/supabase/server'

// What gets returned — everything an API route needs to know about the caller
export interface OrgContext {
  userId: string
  orgId:  string
  role:   'owner' | 'admin' | 'viewer' | 'accountant'
  plan:   'trial' | 'starter' | 'pro' | 'enterprise' | 'past_due'
}

/**
 * getOrgFromRequest(request)
 *
 * Reads the Bearer token from the Authorization header,
 * verifies it with Supabase, and returns the user's org context.
 *
 * Returns null if the token is missing or invalid.
 */
export async function getOrgFromRequest(request: Request): Promise<OrgContext | null> {
  // Get the token from the Authorization header
  // The browser sends: "Authorization: Bearer eyJ..."
  const token = request.headers.get('authorization')?.replace('Bearer ', '')
  if (!token) return null

  const supabase = createAdminClient()

  // Verify the token and get the user
  const { data: { user }, error } = await supabase.auth.getUser(token)
  if (error || !user) return null

  // Look up which organisation this user belongs to and what their role is
  const { data: membership } = await supabase
    .from('organisation_members')
    .select(`
      org_id,
      role,
      organisations (
        plan,
        is_active
      )
    `)
    .eq('user_id', user.id)
    .single()

  if (!membership) return null

  // Block access if the account is suspended
  const org = membership.organisations as any
  if (!org?.is_active) return null

  return {
    userId: user.id,
    orgId:  membership.org_id,
    role:   membership.role as OrgContext['role'],
    plan:   (org?.plan || 'trial') as OrgContext['plan'],
  }
}

/**
 * requireRole(auth, minRole)
 *
 * Throws a 403 Response if the user doesn't have a high enough role.
 * Role hierarchy: owner > admin > viewer > accountant
 *
 * Usage:
 *   requireRole(auth, 'admin')  // only owners and admins can proceed
 */
export function requireRole(auth: OrgContext, minRole: 'admin' | 'owner') {
  const RANK: Record<string, number> = {
    accountant: 0,
    viewer:     1,
    admin:      2,
    owner:      3,
  }

  if ((RANK[auth.role] ?? 0) < RANK[minRole]) {
    throw Response.json(
      { error: 'You do not have permission to perform this action.' },
      { status: 403 }
    )
  }
}
