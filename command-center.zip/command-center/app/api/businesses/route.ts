// app/api/businesses/route.ts
//
// Returns all businesses for the current org, each with their
// latest month's financial data joined in.
//
// Called by BizContext on mount:
//   GET /api/businesses
//   Authorization: Bearer <jwt>
//
// Returns: Business[] — the same shape BizContext expects

import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient }         from '@/lib/supabase/server'
import { getOrgFromRequest }         from '@/lib/auth/get-org'
import { colourForIndex }            from '@/context/BizContext'

export async function GET(req: NextRequest) {
  // 1. Verify who is calling this — get their org
  const auth = await getOrgFromRequest(req)
  if (!auth) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 })
  }

  const supabase = createAdminClient()

  // 2. Get the current year and month so we join the right tracker_data row
  const now   = new Date()
  const year  = now.getFullYear()
  const month = now.getMonth() + 1  // JavaScript months are 0-indexed, SQL months are 1-indexed

  // 3. Fetch all active businesses for this org
  //    LEFT JOIN tracker_data — if no data exists yet, we still return the business (with 0s)
  const { data: businesses, error } = await supabase
    .from('businesses')
    .select(`
      id,
      name,
      type,
      city,
      org_number,
      colour,
      target_staff_pct,
      target_food_pct,
      target_rent_pct,
      target_margin_pct,
      tracker_data (
        revenue,
        staff_cost,
        food_cost,
        rent_cost,
        other_cost,
        net_profit,
        margin_pct
      )
    `)
    .eq('org_id', auth.orgId)
    .eq('is_active', true)
    // Filter tracker_data to current month only
    .eq('tracker_data.period_year',  year)
    .eq('tracker_data.period_month', month)
    .order('name')

  if (error) {
    console.error('Businesses fetch error:', error)
    return NextResponse.json({ error: 'Failed to load businesses' }, { status: 500 })
  }

  // 4. Shape the data into what BizContext expects
  //    Supabase returns tracker_data as an array (even though there's at most 1 row) — take [0]
  const shaped = (businesses ?? []).map((biz, i) => {
    const tracker = Array.isArray(biz.tracker_data)
      ? biz.tracker_data[0]
      : biz.tracker_data

    const revenue    = Number(tracker?.revenue    ?? 0)
    const staff_cost = Number(tracker?.staff_cost ?? 0)
    const food_cost  = Number(tracker?.food_cost  ?? 0)
    const rent_cost  = Number(tracker?.rent_cost  ?? 0)
    const other_cost = Number(tracker?.other_cost ?? 0)
    const net_profit = Number(tracker?.net_profit ?? 0)
    const margin     = Number(tracker?.margin_pct ?? 0)

    // Derive percentage columns (avoid dividing by zero)
    const staffPct = revenue > 0 ? Math.round(staff_cost / revenue * 100) : 0
    const foodPct  = revenue > 0 ? Math.round(food_cost  / revenue * 100) : 0
    const rentPct  = revenue > 0 ? Math.round(rent_cost  / revenue * 100) : 0

    return {
      id:                biz.id,
      name:              biz.name,
      type:              biz.type,
      city:              biz.city,
      org_number:        biz.org_number,
      // Use stored colour or fall back to palette — ensures consistent colours per business
      colour:            biz.colour ?? colourForIndex(i),
      target_staff_pct:  Number(biz.target_staff_pct  ?? 40),
      target_food_pct:   Number(biz.target_food_pct   ?? 31),
      target_rent_pct:   Number(biz.target_rent_pct   ?? 13),
      target_margin_pct: Number(biz.target_margin_pct ?? 12),
      // Financial actuals for current month
      revenue,
      staff_cost,
      food_cost,
      rent_cost,
      other_cost,
      net_profit,
      margin,
      staffPct,
      foodPct,
      rentPct,
    }
  })

  return NextResponse.json(shaped)
}
