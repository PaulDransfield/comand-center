// app/api/chat/route.ts
//
// THE AI CHAT ENDPOINT — streams Claude's response word-by-word to the browser.
//
// Uses Server-Sent Events (SSE) — think of it as a one-way radio:
// the server broadcasts text tokens as they arrive from Anthropic,
// and the browser displays them as they come in (the "typing" effect).
//
// Request format:
//   POST /api/chat
//   Authorization: Bearer <jwt>
//   Content-Type: application/json
//   { messages: [{role, content}], context?: string, notebookId?: string }
//
// Response: text/event-stream
//   data: {"type":"delta","text":"Hello"}
//   data: {"type":"delta","text":" world"}
//   data: {"type":"done","usage":{"inputTokens":120,"outputTokens":45}}

import { NextRequest }   from 'next/server'
import Anthropic         from '@anthropic-ai/sdk'
import { getOrgFromRequest } from '@/lib/auth/get-org'
import { createAdminClient } from '@/lib/supabase/server'
import { PLANS }             from '@/lib/stripe/config'
import { rateLimit }         from '@/lib/middleware/rate-limit'

// Tell Next.js this route streams — don't buffer the response
export const dynamic = 'force-dynamic'

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
})

export async function POST(req: NextRequest) {
  // ── 1. Auth check ────────────────────────────────────────────
  const auth = await getOrgFromRequest(req)
  if (!auth) {
    return new Response('Not authenticated', { status: 401 })
  }

  // ── 2. Rate limit (AI calls — most expensive) ────────────────
  const limit = await rateLimit(req, auth, 'ai')
  if (!limit.ok) return limit.response!

  // ── 3. Parse request body ────────────────────────────────────
  const { messages, context, notebookId } = await req.json()

  if (!messages?.length) {
    return new Response('No messages provided', { status: 400 })
  }

  // ── 3. Check usage limits ────────────────────────────────────
  const supabase = createAdminClient()
  const month    = new Date().toISOString().slice(0, 7)  // "2026-03"

  const { data: usage } = await supabase
    .from('ai_usage')
    .select('total_tokens, total_requests')
    .eq('org_id', auth.orgId)
    .eq('month', month)
    .maybeSingle()

  const plan       = PLANS[auth.plan] ?? PLANS.trial
  const limits     = plan.limits
  const usedTokens = usage?.total_tokens   ?? 0
  const usedReqs   = usage?.total_requests ?? 0

  // Block if over the monthly limit
  if (usedTokens >= limits.monthly_tokens || usedReqs >= limits.monthly_requests) {
    return Response.json({
      error:       'Monthly AI limit reached',
      code:        'USAGE_LIMIT',
      upgradeHint: `Upgrade to ${plan.name === 'Pro' ? 'Enterprise' : 'Pro'} for more AI usage`,
      upgrade_url: '/upgrade',
    }, { status: 402 })
  }

  // ── 4. Choose model based on plan ────────────────────────────
  // Trial users get Haiku (fast, cheap) — paid users get Sonnet (best quality)
  const model = plan.model

  // ── 5. Build system prompt ───────────────────────────────────
  const systemPrompt = buildSystemPrompt(context)

  // ── 6. Start SSE stream ──────────────────────────────────────
  const encoder = new TextEncoder()

  // ReadableStream lets us push data to the browser as we receive it from Anthropic
  const stream = new ReadableStream({
    async start(controller) {
      function send(data: object) {
        // SSE format: "data: {json}\n\n"
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`))
      }

      let inputTokens  = 0
      let outputTokens = 0

      try {
        // Stream from Anthropic API
        const anthropicStream = anthropic.messages.stream({
          model,
          max_tokens: 4096,
          system:     systemPrompt,
          messages:   messages.map((m: { role: string; content: string }) => ({
            role:    m.role === 'assistant' ? 'assistant' : 'user',
            content: m.content,
          })),
        })

        // Forward each token to the browser as it arrives
        for await (const event of anthropicStream) {
          if (event.type === 'content_block_delta') {
            send({ type: 'delta', text: event.delta.text })
          }
          // Track token counts from Anthropic's usage reports
          if (event.type === 'message_start') {
            inputTokens = event.message.usage?.input_tokens ?? 0
          }
          if (event.type === 'message_delta') {
            outputTokens = event.usage?.output_tokens ?? 0
          }
        }

        // Signal completion
        send({ type: 'done', usage: { inputTokens, outputTokens } })

        // ── 7. Record usage in Supabase ─────────────────────────
        // Fire-and-forget — don't block the response waiting for this
        const totalTokens = inputTokens + outputTokens
        const costUsd     = estimateCost(model, inputTokens, outputTokens)

        // Atomic upsert — if a row exists for this org+month, increment it
        // If not, create it. This prevents race conditions with concurrent requests.
        supabase.rpc('increment_ai_usage', {
          p_org_id:        auth.orgId,
          p_month:         month,
          p_tokens:        totalTokens,
          p_input_tokens:  inputTokens,
          p_output_tokens: outputTokens,
          p_requests:      1,
          p_cost_usd:      costUsd,
        }).then(({ error }) => {
          if (error) console.error('Usage tracking failed:', error.message)
        })

      } catch (err) {
        // Send the error to the browser so the UI can show it
        send({ type: 'error', message: (err as Error).message })
      } finally {
        controller.close()
      }
    },
  })

  // Return the stream with SSE content-type header
  return new Response(stream, {
    headers: {
      'Content-Type':  'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection':    'keep-alive',
    },
  })
}

// ── Helpers ───────────────────────────────────────────────────────

function buildSystemPrompt(context?: string): string {
  const base = `You are a business intelligence assistant for CommandCenter, a restaurant management platform in Sweden.

Your job is to help restaurant owners understand their financial data, answer questions about their business, and provide actionable recommendations.

CRITICAL RULES:
1. If document sources are provided, base your answers on those sources. Always cite which document you're drawing from using [Source: filename].
2. If you don't have enough information from the sources to answer confidently, say so clearly — don't guess or use general knowledge for specific financial figures.
3. Format numbers in Swedish style: 224 978 kr (spaces as thousands separators).
4. Be direct and practical — restaurant owners are busy. Lead with the key finding, then explain.
5. When identifying problems (e.g. staff cost over target), suggest a specific, actionable next step.`

  if (context) {
    return `${base}\n\nSOURCE DOCUMENTS:\n${context}`
  }

  return base
}

// Approximate cost in USD based on current Anthropic pricing
function estimateCost(model: string, inputTokens: number, outputTokens: number): number {
  const pricing: Record<string, { input: number; output: number }> = {
    'claude-haiku-4-5-20251001': { input: 0.00025,  output: 0.00125  },
    'claude-sonnet-4-6':         { input: 0.003,    output: 0.015    },
  }
  const rates = pricing[model] ?? pricing['claude-sonnet-4-6']
  return (inputTokens / 1000 * rates.input) + (outputTokens / 1000 * rates.output)
}
