// app/layout.tsx
//
// The ROOT LAYOUT — wraps every single page in the app.
// Sets the HTML structure, fonts, and global styles.
// Think of it as the frame around a painting — every page goes inside this frame.

import type { Metadata } from 'next'
import './globals.css'
import './mobile.css'

export const metadata: Metadata = {
  title: {
    // Each page can set its own title; this is the fallback
    default:  'CommandCenter',
    template: '%s — CommandCenter',
  },
  description: 'AI-powered business intelligence for Swedish restaurants',
  robots: {
    index:  false,  // Don't index in search engines yet (pre-launch)
    follow: false,
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="sv">  {/* sv = Swedish, affects browser spell check etc */}
      <body>
        {children}
      </body>
    </html>
  )
}
