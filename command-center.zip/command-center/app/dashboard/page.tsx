// app/dashboard/page.tsx
//
// THE MAIN DASHBOARD — the first thing users see after login.
//
// Shows EITHER:
//   - Individual view: KPIs for one selected business
//   - Aggregate view:  Combined group P&L across all businesses
//
// All data comes from BizContext (which fetches from /api/businesses).
// No data fetching happens in this component — it just renders what BizContext provides.

'use client'

import { useBiz }    from '@/context/BizContext'
import KPICard       from '@/components/dashboard/KPICard'
import type { Business, AggregateData } from '@/context/BizContext'

export default function DashboardPage() {
  const biz = useBiz()

  // Loading state
  if (biz.loading) {
    return (
      <div style={S.centred}>
        <span className="spin" style={{ fontSize: 24, color: 'var(--ink-4)' }}>⟳</span>
        <p style={{ marginTop: 12, color: 'var(--ink-4)', fontSize: 13 }}>Loading your businesses…</p>
      </div>
    )
  }

  // Error state
  if (biz.error) {
    return (
      <div style={S.centred}>
        <p style={{ color: 'var(--red)', fontSize: 13 }}>⚠ {biz.error}</p>
        <button className="btn btn-sm" style={{ marginTop: 12 }} onClick={biz.refresh}>
          Try again
        </button>
      </div>
    )
  }

  // No businesses yet — show empty state
  if (!biz.businesses.length) {
    return <EmptyState />
  }

  // Choose which view to show
  if (biz.isAggregate && biz.aggregate) {
    return <AggregateView data={biz.aggregate} />
  }

  if (biz.current) {
    return <IndividualView biz={biz.current} />
  }

  // Has businesses but nothing selected yet
  return (
    <div style={S.centred}>
      <p style={{ color: 'var(--ink-4)', fontSize: 13 }}>Select a business from the top bar to get started.</p>
    </div>
  )
}

// ── INDIVIDUAL VIEW ───────────────────────────────────────────────

function IndividualView({ biz }: { biz: Business }) {
  const fmt   = (n: number) => Math.round(n).toLocaleString('sv-SE') + ' kr'
  const fmtPct = (n: number) => n.toFixed(1) + '%'
  const month = new Date().toLocaleDateString('sv-SE', { month: 'long', year: 'numeric' })

  // Determine delta direction for each metric
  // In a real app you'd compare to last month from a second query
  // For now we show vs target
  const staffOver  = biz.staffPct  - biz.target_staff_pct
  const foodOver   = biz.foodPct   - biz.target_food_pct
  const rentOver   = biz.rentPct   - biz.target_rent_pct
  const marginDiff = biz.margin    - biz.target_margin_pct

  return (
    <div style={S.page}>

      {/* Page header */}
      <div style={S.header}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
            <div style={{ ...S.bizDot, background: biz.colour }} />
            <h1 style={S.title}>{biz.name}</h1>
          </div>
          <p style={S.subtitle}>
            {biz.type ?? 'Restaurant'}{biz.city ? ` · ${biz.city}` : ''} · {month}
          </p>
        </div>
        <button className="btn btn-sm" onClick={() => window.location.href = '/notebook'}>
          Ask AI about this business →
        </button>
      </div>

      {/* KPI grid */}
      <div style={S.kpiGrid}>

        <KPICard
          label="Revenue"
          value={fmt(biz.revenue)}
          accent={biz.colour}
          overIsGood
          sub={biz.revenue === 0 ? 'No data for this month yet' : undefined}
        />

        <KPICard
          label="Net Profit"
          value={fmt(biz.net_profit)}
          accent={biz.margin >= biz.target_margin_pct ? 'var(--green)' : 'var(--amber)'}
          overIsGood
          target={biz.target_margin_pct}
          actual={biz.margin}
          sub={`${fmtPct(biz.margin)} margin · target ${fmtPct(biz.target_margin_pct)}`}
        />

        <KPICard
          label="Staff Cost"
          value={fmt(biz.staff_cost)}
          target={biz.target_staff_pct}
          actual={biz.staffPct}
          sub={`${fmtPct(biz.staffPct)} of revenue · target ${fmtPct(biz.target_staff_pct)}`}
        />

        <KPICard
          label="Food Cost"
          value={fmt(biz.food_cost)}
          target={biz.target_food_pct}
          actual={biz.foodPct}
          sub={`${fmtPct(biz.foodPct)} of revenue · target ${fmtPct(biz.target_food_pct)}`}
        />

        <KPICard
          label="Rent"
          value={fmt(biz.rent_cost)}
          target={biz.target_rent_pct}
          actual={biz.rentPct}
          sub={`${fmtPct(biz.rentPct)} of revenue · target ${fmtPct(biz.target_rent_pct)}`}
        />

        <KPICard
          label="Other Costs"
          value={fmt(biz.other_cost)}
          sub="Utilities, admin, marketing"
        />

      </div>

      {/* Alert strip — shows if any metric is significantly over target */}
      {(staffOver > 2 || foodOver > 2 || marginDiff < -2) && (
        <div style={S.alertStrip}>
          <span style={{ fontSize: 16 }}>⚠</span>
          <span>
            {staffOver > 2
              ? `Staff cost is ${staffOver.toFixed(1)}pp above the ${fmtPct(biz.target_staff_pct)} target. `
              : ''}
            {foodOver > 2
              ? `Food cost is ${foodOver.toFixed(1)}pp above the ${fmtPct(biz.target_food_pct)} target. `
              : ''}
            {marginDiff < -2
              ? `Margin is ${Math.abs(marginDiff).toFixed(1)}pp below the ${fmtPct(biz.target_margin_pct)} target.`
              : ''}
          </span>
          <button
            className="btn btn-sm"
            onClick={() => window.location.href = '/notebook'}
            style={{ marginLeft: 'auto', whiteSpace: 'nowrap', flexShrink: 0 }}
          >
            Ask AI for advice →
          </button>
        </div>
      )}

      {/* Quick links */}
      <div style={S.quickLinks}>
        {[
          { label: '📚 Open Notebook',     href: '/notebook'      },
          { label: '📊 Full Tracker',      href: '/tracker'       },
          { label: '✦ Generate Report',   href: '/studio'        },
          { label: '⟳ Integrations',      href: '/integrations'  },
        ].map(({ label, href }) => (
          <a key={href} href={href} style={S.quickLink}>{label}</a>
        ))}
      </div>

    </div>
  )
}

// ── AGGREGATE VIEW ────────────────────────────────────────────────

function AggregateView({ data }: { data: AggregateData }) {
  const fmt    = (n: number) => Math.round(n).toLocaleString('sv-SE') + ' kr'
  const fmtPct = (n: number) => n.toFixed(1) + '%'
  const month  = new Date().toLocaleDateString('sv-SE', { month: 'long', year: 'numeric' })

  return (
    <div style={S.page}>

      <div style={S.header}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
            <span style={{ fontSize: 20 }}>⊞</span>
            <h1 style={S.title}>Group Overview</h1>
          </div>
          <p style={S.subtitle}>{data.count} locations · {month}</p>
        </div>
        <button className="btn btn-sm" onClick={() => window.location.href = '/notebook'}>
          Ask AI about the group →
        </button>
      </div>

      {/* Group KPIs */}
      <div style={S.kpiGrid}>
        <KPICard
          label="Group Revenue"
          value={fmt(data.revenue)}
          overIsGood
        />
        <KPICard
          label="Group Profit"
          value={fmt(data.profit)}
          overIsGood
          sub={`${fmtPct(data.margin)} blended margin`}
        />
        <KPICard
          label="Avg Staff %"
          value={fmtPct(data.staffPct)}
          target={40}
          actual={data.staffPct}
          sub={`Weighted avg · target 40%`}
        />
        <KPICard
          label="Avg Food %"
          value={fmtPct(data.foodPct)}
          target={31}
          actual={data.foodPct}
          sub={`Weighted avg · target 31%`}
        />
        <KPICard
          label="Avg Rent %"
          value={fmtPct(data.rentPct)}
          target={13}
          actual={data.rentPct}
          sub={`Weighted avg · target 13%`}
        />
        <KPICard
          label="Locations"
          value={String(data.count)}
          sub="Reporting this month"
        />
      </div>

      {/* Revenue contribution table */}
      <div className="card" style={{ marginTop: 20 }}>
        <div className="card-header">
          <span className="card-title">Revenue by location</span>
        </div>
        <div style={{ padding: '4px 0' }}>
          {data.contributions
            .sort((a, b) => b.revenue - a.revenue)
            .map(c => (
              <div key={c.id} style={S.contribRow}>
                <div style={{ ...S.contribDot, background: c.colour }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--ink)' }}>{c.name}</div>
                  <div style={{ ...S.barWrap }}>
                    <div style={{ ...S.contribBar, width: `${c.pct}%`, background: c.colour + '80' }} />
                  </div>
                </div>
                <div style={{ textAlign: 'right' as const, flexShrink: 0 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, fontFamily: 'var(--mono)', color: 'var(--ink)' }}>
                    {Math.round(c.revenue).toLocaleString('sv-SE')} kr
                  </div>
                  <div style={{ fontSize: 10, color: 'var(--ink-4)' }}>
                    {c.pct}% · {c.margin.toFixed(1)}% margin
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>

    </div>
  )
}

// ── EMPTY STATE ───────────────────────────────────────────────────

function EmptyState() {
  return (
    <div style={S.centred}>
      <div style={{ fontSize: 48, marginBottom: 16 }}>🏪</div>
      <h2 style={{ fontFamily: 'var(--display)', fontWeight: 400, fontStyle: 'italic', color: 'var(--navy)', marginBottom: 8 }}>
        Add your first restaurant
      </h2>
      <p style={{ fontSize: 13, color: 'var(--ink-3)', maxWidth: 320, textAlign: 'center', lineHeight: 1.6, marginBottom: 20 }}>
        Once you add a business, you'll see live financial KPIs, cost tracking, and AI insights here.
      </p>
      <button className="btn btn-primary" onClick={() => window.location.href = '/integrations'}>
        Set up your first location →
      </button>
    </div>
  )
}

// ── Styles ────────────────────────────────────────────────────────

const S: Record<string, React.CSSProperties> = {
  page: {
    padding:   '24px',
    maxWidth:  '960px',
  },
  centred: {
    display:        'flex',
    flexDirection:  'column',
    alignItems:     'center',
    justifyContent: 'center',
    height:         '60vh',
    textAlign:      'center',
    padding:        '32px',
  },
  header: {
    display:        'flex',
    alignItems:     'flex-start',
    justifyContent: 'space-between',
    marginBottom:   '24px',
    gap:            16,
  },
  bizDot: {
    width:          '12px',
    height:         '12px',
    borderRadius:   '50%',
    flexShrink:     0,
  },
  title: {
    fontFamily: 'var(--display)',
    fontSize:   '26px',
    fontWeight: 400,
    fontStyle:  'italic',
    color:      'var(--navy)',
    lineHeight: 1.2,
    margin:     0,
  },
  subtitle: {
    fontSize:  '12px',
    color:     'var(--ink-4)',
    marginTop: '4px',
  },
  kpiGrid: {
    display:             'grid',
    gridTemplateColumns: 'repeat(3, 1fr)',
    gap:                 '12px',
    marginBottom:        '16px',
  },
  alertStrip: {
    background:   'var(--amber-lt)',
    border:       '1px solid rgba(122,72,0,.2)',
    borderRadius: 'var(--radius)',
    padding:      '12px 16px',
    fontSize:     '13px',
    color:        'var(--amber)',
    display:      'flex',
    alignItems:   'center',
    gap:          '10px',
    marginBottom: '16px',
    lineHeight:   1.5,
  },
  quickLinks: {
    display:  'flex',
    gap:      '8px',
    flexWrap: 'wrap',
  },
  quickLink: {
    padding:       '8px 14px',
    background:    'var(--white)',
    border:        '1px solid var(--border)',
    borderRadius:  '9px',
    fontSize:      '12px',
    fontWeight:    500,
    color:         'var(--ink-2)',
    textDecoration:'none',
    transition:    'border-color .12s',
  },
  contribRow: {
    display:     'flex',
    alignItems:  'center',
    gap:         '12px',
    padding:     '10px 18px',
    borderBottom:'1px solid var(--border)',
  },
  contribDot: {
    width:        '10px',
    height:       '10px',
    borderRadius: '50%',
    flexShrink:   0,
  },
  barWrap: {
    height:       '4px',
    background:   'var(--border)',
    borderRadius: '2px',
    overflow:     'hidden',
    marginTop:    '4px',
  },
  contribBar: {
    height:       '100%',
    borderRadius: '2px',
    transition:   'width .5s ease',
  },
}
